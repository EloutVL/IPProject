package com.journaldev.expandablelistview;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ExpandableListDataPump {
    public static HashMap<String, List<String>> getData() {
        HashMap<String, List<String>> expandableListDetail = new HashMap<String, List<String>>();

        List<String> welcome = new ArrayList<String>();
        welcome.add("Benvingut");
        welcome.add("Benvinguda");
        welcome.add("Benvinguts");
        welcome.add("Benvingudes");

        List<String> hello = new ArrayList<String>();
        hello.add("Hola");
        hello.add("Bon dia");

        List<String> howAreYou = new ArrayList<String>();
        howAreYou.add("Com estàs");
        howAreYou.add("Com està (Polite)");

        List<String> replyHowAreYou = new ArrayList<String>();
        replyHowAreYou.add("Bé, gràcias, i tu?");
        replyHowAreYou.add("Bé, gràcias, i vosté? (Polite)");

        List<String> goodMorning = new ArrayList<>();
        goodMorning.add("Bon dia");

        List<String> goodAfternoon = new ArrayList<>();
        goodAfternoon.add("Bona tarda");

        List<String> goodEvening = new ArrayList<>();
        goodAfternoon.add("Bona nit");

        List<String> goodbye = new ArrayList<>();
        goodbye.add("Adéu!");

        List<String> cheers = new ArrayList<>();
        cheers.add("Salut!");

        List<String> haveANiceMeal = new ArrayList<>();
        haveANiceMeal.add("Bon profit!");

        List<String> iUnderstand = new ArrayList<>();
        iUnderstand.add("(No ho) Entenc");

        List<String> yesNo = new ArrayList<>();
        yesNo.add("Sí / No");

        List<String> maybe = new ArrayList<>();
        maybe.add("Potser");

        List<String> iDontKnow = new ArrayList<>();
        iDontKnow.add("No sé");

        List<String> pleaseSpeakMoreSlowly = new ArrayList<>();
        pleaseSpeakMoreSlowly.add("Parli més a poc a poc, si us plau?");

        List<String> pleaseSayThatAgain = new ArrayList<>();
        pleaseSayThatAgain.add("M'ho pot repeti, si us plau?");

        List<String> pleaseWriteItDown = new ArrayList<>();
        pleaseWriteItDown.add("Pot escriure-ho, si us plau?");

        List<String> doYouSpeakEnglish = new ArrayList<>();
        doYouSpeakEnglish.add("Que parla anglès?");

        List<String> doYouSpeakCatalan = new ArrayList<>();
        doYouSpeakEnglish.add("Que parla català?");

        List<String> yesALittle = new ArrayList<>();
        yesALittle.add("Sí, un poc");

        List<String> howDoYouSay = new ArrayList<>();
        howDoYouSay.add("Com es diu en català ...");

        List<String> excuseMe = new ArrayList<>();
        excuseMe.add("Dispensi");

        List<String> howMuchIsThis = new ArrayList<>();
        howMuchIsThis.add("Quant costa això?");

        List<String> sorry = new ArrayList<>();
        sorry.add("Perdó");

        List<String> please = new ArrayList<>();
        please.add("Si us plau");

        List<String> thankYou = new ArrayList<>();
        thankYou.add("Gràcies");

        List<String> replyThankYou = new ArrayList<>();
        replyThankYou.add("De res");

        List<String> wheresTheToilet = new ArrayList<>();
        wheresTheToilet.add("On és el lavabo?");

        List<String> help = new ArrayList<>();
        help.add("Socors!");

        List<String> fire = new ArrayList<>();
        fire.add("Foc!");

        List<String> stop = new ArrayList<>();
        stop.add("Alto!");

        List<String> myNameIs = new ArrayList<>();
        myNameIs.add("El meu nom és ...");

        expandableListDetail.put("Welcome", welcome);
        expandableListDetail.put("Hello", hello);
        expandableListDetail.put("How are you?", howAreYou);
        expandableListDetail.put("Reply to How Are You?", replyHowAreYou);
        expandableListDetail.put("Good morning", goodMorning);
        expandableListDetail.put("Good afternoon", goodAfternoon);
        expandableListDetail.put("Good evening", goodEvening);
        expandableListDetail.put("Goodbye", goodbye);
        expandableListDetail.put("Cheers!", cheers);
        expandableListDetail.put("Have a nice meal!", haveANiceMeal);
        expandableListDetail.put("I (don't) understand", iUnderstand);
        expandableListDetail.put("Yes / no", yesNo);
        expandableListDetail.put("Maybe", maybe);
        expandableListDetail.put("I don't know", iDontKnow);
        expandableListDetail.put("Please speak more slowly", pleaseSpeakMoreSlowly);
        expandableListDetail.put("Please say that again", pleaseSayThatAgain);
        expandableListDetail.put("Please write it down", pleaseWriteItDown);
        expandableListDetail.put("Do you speak English?", doYouSpeakEnglish);
        expandableListDetail.put("Do you speak Catalan?", doYouSpeakCatalan);
        expandableListDetail.put("Yes, a little", yesALittle);
        expandableListDetail.put("How do you say ... in Catalan?", howDoYouSay);
        expandableListDetail.put("Excuse me", excuseMe);
        expandableListDetail.put("Sorry", sorry);
        expandableListDetail.put("Please", please);
        expandableListDetail.put("Thank you", thankYou);
        expandableListDetail.put("Reply to thank you", replyThankYou);
        expandableListDetail.put("Where's the toilet?", wheresTheToilet);
        expandableListDetail.put("Help!", help);
        expandableListDetail.put("Fire!", fire);
        expandableListDetail.put("Stop!", stop);
        expandableListDetail.put("My name is ...", myNameIs);

        return expandableListDetail;
    }
}
